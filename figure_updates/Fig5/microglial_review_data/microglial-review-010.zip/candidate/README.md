# Figure 5 retrained classifier candidate

Trained from 203 confirmed human mask/class reviews across 15 animals. No pseudo-labels entered training. The original microscopy and class labels remain unchanged.

Whole-animal validation: **59.5% balanced accuracy**, 62.5% accuracy. The selected checkpoint is epoch 36 of 42 completed epochs. Validation was used for early stopping and is not an independent final test set.

Existing morphometric proposals scored **74.6% balanced accuracy** on the same 40 reviewed validation cells. Candidate only; the CNN underperforms the existing morphometric proposals on the same reviewed validation cells.

| Class | Validation cells | Correct | Recall |
|---|---:|---:|---:|
| Ramified | 8 | 8 | 100.0% |
| Rod-like | 6 | 2 | 33.3% |
| Activated | 11 | 2 | 18.2% |
| Amoeboid | 15 | 13 | 86.7% |

The first run collapsed to one class because normalization statistics still reflected their initial defaults. Recalibration uses only unaugmented training cells and preserves optimization randomness. The 25-epoch calibrated run was still improving at its cap; the final run raised the cap to 100 while preserving the split, seed, optimizer, and early-stopping patience of six epochs. Earlier runs are preserved alongside this directory.

These outputs remain candidates for scientific review. Class-specific errors in the table limit automatic use. The balanced review sample does not estimate population class prevalence.

Artifacts: [model](models/microglia_morphology_cnn.pt), [assessment](retraining_assessment.pdf), [training report](retraining_report.json), [integrity checks](verification_report.json), [predictions](per_microglia_classifier_predictions.csv).

Reproduce from the Paper root with the command stored in the campaign training_status.json. Exact analysis and training source files are retained under source_code/.
